import os
import subprocess
import sys
import shutil

def main():
    try:
        # Change directory to Engine/scenes
        os.chdir("scenes")

        # Run the command to create the scene
        subprocess.run(["dub"], check=True)

        # Move gamescene.d from Engine/scenes/outputs to Engine/source/scenes
        source_path = "outputs/gamescene.d"
        destination_path = "../source/scenes/gamescene.d"
        if not os.path.exists("../source/scenes"):
            raise FileNotFoundError("Destination directory does not exist: ../source/scenes")
        shutil.move(source_path, destination_path)

        # Change directory back to Engine
        os.chdir("../")

        # Run the dub command
        subprocess.run(["dub"], check=True)

        # Exit the script
        sys.exit(0)

    except FileNotFoundError as e:
        print(f"Error: {e}")
        sys.exit(1)
    except subprocess.CalledProcessError as e:
        print(f"Command failed with return code {e.returncode}: {e.cmd}")
        sys.exit(1)
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
