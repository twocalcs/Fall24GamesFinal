Creates a scene file by reading a JSON file.

Usage: ./createscene <input.json> <output.d>
Example usage: ./createscene basicscene.json basicscene.d

Note: 
- input.json is assumed to be in scenes/inputs
- output.d is created in scene/outputs