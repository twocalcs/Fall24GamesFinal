#!/bin/bash

generate_package_file() {
    local folder=$1
    local package_file="source/$folder/package.d"

    # delete the package.d file if it already exists
    rm -f "$package_file"

    # Loop through each .d file in the folder
    for file in "source/$folder"/*.d; do
        # if file == package.d, skip it
        if [ "$file" = "package" ]; then
            continue
        fi
        # Get the base name of the file without the extension
        base_name=$(basename "$file" .d)
        # Append the import statement to the package.d file
        echo "public import $folder.$base_name;" >> "$package_file"
    done

    echo "module $folder;" | cat - $package_file > temp && mv temp $package_file
}

# Generate package.d for components folder
generate_package_file "components"

# Generate package.d for scripts folder
generate_package_file "scripts"

generate_package_file "scenes"


echo "package.d files have been generated in the components and scripts folders."